package accessmodifier;

public class accessSpecifiers2 {

}
