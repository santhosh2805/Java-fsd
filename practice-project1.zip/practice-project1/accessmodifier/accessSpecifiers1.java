package accessmodifier;

public class accessSpecifiers1 {

}
