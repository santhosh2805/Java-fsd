package innerclass;

public abstract class anonymosInnerClass {

}
