package pack1;

public class pubaccessspecifier {

}
